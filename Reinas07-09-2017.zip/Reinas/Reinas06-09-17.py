# -*- coding: utf-8 -*-
"""
Created on Thu Sep 07 01:35:13 2017

@author: Alex
"""

def bt_queens(k,n,X):
    if k >= n:
        return
    X[k] = 0
    while True:
        X[k] += 1  # select new option increase X[k]
        if validate(k,X):  # test constraints
            if k != n-1:
                bt_queens(k + 1, n, X)
            else:
                print 'Solution:', X
                return X
        if X[k] == n:
            break


def validate(k,X):
    for i in range(k):
        if X[i] == X[k] or abs(X[i] - X[k]) == abs(i - k):
            return False
    return True

bt_queens(0, 8, [0] * 8)

def bt_queens1(k,n,X):
    if k >= n:
        return
    X[k] = 0
    while True:
        X[k] += 2  # select new option increase X[k]
        if validate1(k,X):  # test constraints
            if k != n-2:
                bt_queens1(k + 2, n, X)
            else:
                print 'Solution:', X
                return X
        if X[k] == n:
            break


def validate1(k,X):
    for i in range(k):
        if X[i] == X[k] or abs(X[i] - X[k]) == abs(i - k):
            return False
    return True

bt_queens1(0, 8, [0] * 8)

#Add timer 
import time

def time_queens(n, method = 'backtracking'):
    X = [0] * n
    tic = time.time()
    if method == 'backtracking':
        bt_queens(0, n, [0] * n)
    return time.time() - tic

def time_queens1(n, method = 'nuevab'):
    X = [0] * n
    tic = time.time()
    if method == 'nuevab':
        bt_queens1(0, n, [0] * n)
    return time.time() - tic

time_queens1(4)

time_queens(4)

time_bt = []
for i in range(4,14,2):
    time_bt.append(time_queens(i))
    
time_bt1 = []
for i in range(4,14,2):
    time_bt1.append(time_queens(i))
    
%matplotlib inline
import numpy as np
import matplotlib.pyplot as plt

plt.plot(range(4,14,2),time_bt,'-o',label='backtracking')
plt.plot(range(4,14,2),time_bt1,'-ob',label='nuevab')
plt.plot(range(4,18,2),range(4,18,2),'-om',label='line')
plt.legend(loc=2)
plt.ylabel('Time(ms)')
plt.xlabel('n')


