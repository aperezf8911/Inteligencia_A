# -*- coding: utf-8 -*-
"""
Created on Sat Sep 09 16:16:24 2017

@author: Alex
"""

def Reinas(ub_reinas,k,n):
    cont=0
    if k>=n:                             
        return False
    
    Final = False                            
    
    while True:
           
            if (ub_reinas[k] < n):                       
                ub_reinas[k] = ub_reinas[k] + 1       

            if (Valido(ub_reinas,k)):                    
                cont+=1    
                if k != n-1:
                    
                    Final = Reinas(ub_reinas, k+1,n)
                    if Final==False:
                        #print ub_reinas,"ubicacion incorrecta"
                        ub_reinas[k+1] = 0
                        
                else:
                    print "\n"
                    print "Ubicacion Correcta para las",n,"reinas"
                    print ub_reinas
                    print "\n"
                                    
            if (ub_reinas[k]==n or Final==True):         
                break
    return Final



def Valido(ub_reinas,k):
    for i in range(k):
        if(ub_reinas[i] == ub_reinas[k]) or (ValAbs(ub_reinas[i],ub_reinas[k])==ValAbs(i,k)):
            return False
    return True

def ValAbs(x,y):
    if x>y:
        return x - y
    else:
        return y - x


print "PROBLEMA DE LAS N - REINAS PTE POR ENTREGAR"
print "\n"
print "Introduce el numero de reinas:\n"

n = input()
ub_reinas = []
for i in range(n):
    ub_reinas.append(0)
k = 0
print Reinas(ub_reinas, k, n)


# Abre archivo para escribir
#archivo = open('reinas.txt','w')

# Escribe cadena1 añadiendo salto de línea 
#archivo.write(ub_reinas + '\n')

# cierra archivo
#archivo.close

#import csv

#Reinas(ub_reinas, k, n)
#csvfile = "reinas.csv"

#Assuming res is a flat list
#with open(csvfile, "w") as output:
#    writer = csv.writer(output, lineterminator='\n')
#    for val in Reinas(ub_reinas, k, n):
#        writer.writerow([val])    

#Assuming res is a list of lists
#with open(csvfile, "w") as output:
#    writer = csv.writer(output, lineterminator='\n')
#    writer.writerows(Reinas(ub_reinas, k, n))


